package unidad2;

public class VisualizacionDeFiguras {
public static void main(String[] args) {
		
		System.out.println(" *********      ***        *        *");
		System.out.println(" *       *    *     *     ***      * *");
		System.out.println(" *       *   *       *   *****    *   *");
		System.out.println(" *       *   *       *     *     *     *");
		System.out.println(" *       *   *       *     *    *       *");
		System.out.println(" *       *   *       *     *     *     *");
		System.out.println(" *       *   *       *     *      *   *");
		System.out.println(" *       *    *     *      *       * *");
		System.out.println(" *********      ***        *        *");
	}
}