package unidad2;

public class CuadradosYCubos {
	public static void main(String[] args) {
		
		System.out.printf("\n Numero Cuadrado Cubo");
		System.out.printf("\n %6d, %6d, %6d",0,0*0,0*0*0);
		System.out.printf("\n %6d, %6d, %6d",1,1*1,1*1*1);
		System.out.printf("\n %6d, %6d, %6d",2,2*2,2*2*2);
		System.out.printf("\n %6d, %6d, %6d",3,3*3,3*3*3);
		System.out.printf("\n %6d, %6d, %6d",4,4*4,4*4*4);
		System.out.printf("\n %6d, %6d, %6d",5,5*5,5*5*5);
		System.out.printf("\n %6d, %6d, %6d",6,6*6,6*6*6);
		System.out.printf("\n %6d, %6d, %6d",7,7*7,7*7*7);
		System.out.printf("\n %6d, %6d, %6d",8,8*8,8*8*8);
		System.out.printf("\n %6d, %6d, %6d",9,9*9,9*9*9);
		System.out.printf("\n %6d, %6d, %6d",10,10*10,10*10*10);

	}

}